const { Client } = require("pg"); // Importar el cliente de PostgreSQL
const AWS = require("aws-sdk");

exports.handler = async (event) => {
  // Parsear el cuerpo de la solicitud
  const data = JSON.parse(event.body);

  // Parámetros de la oferta
  const amount = data.amount;
  const interestRate = 0.05; // 5% de interés
  const term = 12; // 12 meses

  // Cálculo simple de cuota mensual
  const monthlyPayment = (amount * (1 + interestRate)) / term;

  // Configuración del cliente de PostgreSQL
  const client = new Client({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: 5432, // Puerto predeterminado de PostgreSQL
  });

  try {
    // Conectar a la base de datos
    await client.connect();

    // Insertar datos en la base de datos
    const query =
      "INSERT INTO credit_offers (amount, term, monthly_payment) VALUES ($1, $2, $3)";
    const values = [amount, term, monthlyPayment];
    await client.query(query, values);

    // Respuesta exitosa
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Oferta almacenada con éxito",
        monthlyPayment: monthlyPayment,
      }),
    };
  } catch (error) {
    // Manejo de errores
    console.error("Error al procesar la solicitud:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "Error al procesar la solicitud",
        error: error.message,
      }),
    };
  } finally {
    // Cerrar la conexión a la base de datos
    await client.end();
  }
};
